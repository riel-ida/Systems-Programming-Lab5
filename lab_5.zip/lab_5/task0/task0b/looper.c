#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>

void my_signalHandler(int sig) 
{
    printf("Looper hadling %s\n", strsignal(sig));
    signal(sig, SIG_DFL);
    raise(sig);
    if(sig == SIGTSTP) { signal(SIGCONT, my_signalHandler); }
    if(sig == SIGCONT) { signal(SIGTSTP, my_signalHandler); }
}





int main(int argc, char **argv) { 

	/*printf("\nStarting the program\n");*/

	while(1) 
        {
            signal(SIGTSTP, my_signalHandler);
            signal(SIGCONT, my_signalHandler);
            signal(SIGINT, my_signalHandler);
            sleep(2);
	}

	return 0;

    
}