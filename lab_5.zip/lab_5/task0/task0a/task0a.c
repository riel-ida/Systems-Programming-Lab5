#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <limits.h>
#include <unistd.h>
#include <sys/types.h>
#include "LineParser.h"

#ifndef NULL
    #define NULL 0
#endif

#ifndef PATH_MAX
    #define PATH_MAX 1024
#endif  

#define FREE(X) if(X) free((void*)X)


void execute(cmdLine *pCmdLine)
{    
    if(execvp(pCmdLine->arguments[0], pCmdLine->arguments) < 0) {
        perror("execvp error occurred");
        exit(1);
    }
}


int main(int argc, char *argv[]){
    
    char cwdBuf[PATH_MAX];
    char readBuf[2048];
    cmdLine* pCmdLine;
     
    while(1){
         
        getcwd(cwdBuf, PATH_MAX);
        
        fprintf(stdout, ">%s ", cwdBuf);
        
        fgets(readBuf, sizeof(readBuf), stdin);
        
        if(strcmp(readBuf, "quit\n")==0) {
            exit(0);
        }
        
        pCmdLine = parseCmdLines(readBuf);
        execute(pCmdLine);
        
        freeCmdLines(pCmdLine);
    }
    
    return 0;
}