#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <limits.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "LineParser.h"

#ifndef NULL
    #define NULL 0
#endif

#ifndef PATH_MAX
    #define PATH_MAX 1024
#endif  

#define FREE(X) if(X) free((void*)X)


void execute(cmdLine *pCmdLine)
{
    if(execvp(pCmdLine->arguments[0], pCmdLine->arguments) < 0) {
        perror("execvp error occurred");
        _exit(-1);
    }
}



int main(int argc, char *argv[]){
    int debug = 0;
    char cwdBuf[PATH_MAX];
    char readBuf[2048];
    cmdLine* pCmdLine;
    pid_t childID;
    int status;
     
    while(1){
        
        if(argc > 1) debug = 1; 

        if(debug) {
            fprintf(stderr, "PID: %d\n", getpid());
        }
        
        getcwd(cwdBuf, PATH_MAX);
       
        fprintf(stdout, ">%s ", cwdBuf);
        
        fgets(readBuf, sizeof(readBuf), stdin);
        
        if(strcmp(readBuf, "quit\n")==0) { exit(0); }
        
        pCmdLine = parseCmdLines(readBuf);
        
        if(debug) {
            fprintf(stderr, "Executing command: %s\n", pCmdLine->arguments[0]);
        }
        
        childID = fork();
        
        if(debug) {
            fprintf(stderr, "PID: %d\n", getpid());
        }
        
        if(childID == -1) {
            perror("fork error occurred");
            exit(1);
        }
        
        if(pCmdLine->blocking == 1) {
            if(childID == 0) { execute(pCmdLine); }     /* this is the child process. can execute. */

            else { waitpid(childID, &status, 0); }      /* this is the parent process. blocking == 1: parent will wait for process to end */
        }
        
        else if(childID == 0) { execute(pCmdLine); }    /* blocking == 0: no need to wait for process to end */
        
        freeCmdLines(pCmdLine);
    }
    
    return 0;
}