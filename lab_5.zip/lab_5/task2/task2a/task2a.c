#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <limits.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "LineParser.h"

#ifndef NULL
    #define NULL 0
#endif

#ifndef PATH_MAX
    #define PATH_MAX 1024
#endif  

#define FREE(X) if(X) free((void*)X)


#define TERMINATED  -1
#define RUNNING 1
#define SUSPENDED 0


typedef struct process{
    cmdLine* cmd;                         /* the parsed command line*/
    pid_t pid; 		                  /* the process id that is running the command*/
    int status;                           /* status of the process: RUNNING/SUSPENDED/TERMINATED */
    struct process *next;	                  /* next process in chain */
} process;

process* proc_list = NULL;
pid_t childID;
int status;
int debug = 0;


void addProcess(process** process_list, cmdLine* cmd, pid_t pid) {
        
    process* newProc = (process*)malloc(sizeof(process));
    
    if(newProc == NULL) {
        fprintf(stdout, "malloc error occurred");
        exit(1);
    }
        
    newProc->cmd = cmd;
    
    newProc->pid = pid;
    
    newProc->status = RUNNING;
    
    newProc->next = NULL;
    
    if((*process_list) == NULL) { 
        *process_list = newProc;
        return;
    }
    
    process* tmp = *process_list; /* keep pointing at head */
    
    while(tmp->next) { tmp = tmp->next; }

    tmp->next = newProc; /* (*process_list)->next = NULL */
    
    return;
}


void printProcessList(process** process_list) {
        
       fprintf(stdout, "INDEX\tPID\tSTATUS\tCOMMAND\n");
       
       process* tmp = *process_list; /* keep pointing at head */
              
       if(!tmp) { 
           fprintf(stdout, "no running/suspended processes\n"); 
           return;
       }
       
       int i = 0, j = 0;
       
       while(tmp) 
       {
           fprintf(stdout, "%d\t%d\t%d\t", i, tmp->pid, tmp->status);
           
           while(tmp->cmd->arguments[j]) 
           {
                fprintf(stdout, "%s ", tmp->cmd->arguments[j]); /*command+arguments*/
                j += 1;
           }
           fprintf(stdout, "\n");
           
           i += 1;
           j = 0;
           tmp = tmp->next;
       }
       return;
}


void execute(cmdLine *pCmdLine)
{
    childID = fork();
        
    if(debug) {
        fprintf(stderr, "PID: %d\n", childID);
    }
            
    if(childID == -1) {
        perror("fork error occurred");
        exit(1);
    }
    
    if(childID == 0) { 
        if(execvp(pCmdLine->arguments[0], pCmdLine->arguments) < 0) {
            perror("execvp error occurred");
            _exit(-1);
        }
    }
    
    else {
        addProcess(&proc_list, pCmdLine, childID); 
        if(pCmdLine->blocking == 1) { waitpid(childID, &status, 0); }
    }
}


void my_cd(cmdLine *pCmdLine)
{    
    if(chdir(pCmdLine->arguments[1]) < 0) {
        perror("chdir error occurred");
        _exit(-1);
    }
}


int main(int argc, char *argv[]){
    char cwdBuf[PATH_MAX];
    char* command_line;
     
    while(1){
        
        if(argc > 1) debug = 1;    
        
        if(debug) {
            fprintf(stderr, "PID: %d\n", getpid());
        }
        
        getcwd(cwdBuf, (PATH_MAX));
       
        fprintf(stdout, ">%s ", cwdBuf);
        
        char readBuf[2048];
        
        command_line = fgets(readBuf, 2048, stdin);
        
        if(strcmp(command_line, "quit\n") == 0) { 
            exit(0);
        }
        
        cmdLine* pCmdLine = parseCmdLines(command_line);

        if(debug) {
            fprintf(stderr, "Executing command: %s\n", pCmdLine->arguments[0]);
        }
        
        if(strcmp(pCmdLine->arguments[0], "procs") == 0) { 
            printProcessList(&proc_list);
            freeCmdLines(pCmdLine);
            continue;
        }
        
        
        if(strcmp(pCmdLine->arguments[0], "cd") == 0) {
            my_cd(pCmdLine);
            freeCmdLines(pCmdLine);
            continue;
        }
        
        else execute(pCmdLine);
    }
    
    return 0;
}
